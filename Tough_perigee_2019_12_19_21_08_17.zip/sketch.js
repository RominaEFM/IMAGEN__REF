function setup() {
  createCanvas(500, 500);
  cursor(CROSS);
}

function draw() {
  background(random(300, 100));
  fill(random(+500), random(+150), random(+459))
  
  let numX = 10; // número de elementos en X´
  let numY = 10; // número de elementos en Y´
  
  let m = 20;    // margen
  
  // calculo los espaciadores de x e y
  let spx = (width - 2*m)/(numX - 1);
  let spy = (height - 2*m)/(numY - 1);
  
  // doble for loop
  for (let y = 0; y < numY; y++) {
    for (let x = 0; x < numX; x++) {
      
      // calculo la distancia con el mouse
      let d = dist(mouseX, mouseY, m + x*spx, m + y*spy);
      // mapeo la distancia a un ángulo´
      let r = map(d, 565, width, 4, PI+20);
      
      // reseteo la matriz
      push();
      translate(m + x*spx, m + y*spy); // traslado al punto de la grilla
      rotate(r); // roto en un ángulo proporcional a la distancia
      
      rotate(r); // roto en un ángulo proporcional a la distancia
      rect(0, 4, spx/1.1, 10); // hago una línea horizontal´
       fill(random(+500), random(+10), random(459))
      rect(0, mouseY, mouseX +10, 6); 
      
      pop();
    }
  }

}