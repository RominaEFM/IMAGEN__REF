let angle = 3;
  let a = 10;

let spin = 0.6;
let grow = spin * 1;


function setup() {
  createCanvas(400, 400);
  background(50, 445, 34);
}

function draw() {
  angle += spin *4;
  a = a + grow;
  let x = cos(angle)*a;
  let y = sin(angle)*a;
  translate(200, 200);
  fill(10,10,40,100);
  ellipse(x, y, 40, 40);
  fill(10,10,40);
  ellipse(x, y, 3, 3);
  
 
 
}