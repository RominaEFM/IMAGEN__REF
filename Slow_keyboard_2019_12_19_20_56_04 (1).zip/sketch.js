function setup() {
  createCanvas(710, 400, WEBGL);
}

function draw() {
  background(220);
  fill(random(23), random(456), random(233))
  push();
  rotateZ(frameCount * 0.02);
  rotateX(frameCount * 0.02);
  rotateY(frameCount * 0.02);
  box(80, 80, 80);
  pop();
  
  fill( random(45), random(43), random(379))
  push();
  rotateZ(frameCount * 0.01);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  box(578, 75, 75);
  pop();
  
  fill( random(485), random(43), random(39))
  push();
  rotateZ(frameCount * 0.01);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  box(78, 40, 500);
  pop();
  
  fill( random(285), random(443), random(339))
  push();
  rotateZ(frameCount * 0.01);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  box(48, 600, 40);
  pop();
  
  
  fill( random(285), random(443), random(339), 200)
  push();
  sphere(random(-150), 200, 100);
  pop();
  
}