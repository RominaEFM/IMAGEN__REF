

function setup() {
  createCanvas(400, 400);
  background(140, 35, 66);
  
}

function draw() {
  
 
}
function star(x, y, radius1, radius2, npoints) {
  let angle = TWO_PI / npoints;
  let halfAngle = angle / 2.0;
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius2;
    let sy = y + sin(a) * radius2;
    vertex(sx, sy);
    sx = x + cos(a + halfAngle) * radius1;
    sy = y + sin(a + halfAngle) * radius1;
    vertex(sx, sy);
  }
  endShape(CLOSE);}

function mousePressed(){
stamp(mouseX,mouseY);
}

function stamp(x,y){
  fill( random(+255), random(+506), random(+455))
  push();
  star(x, y, 40, 50, 60);
  pop();
  
  fill(random(+500), random(+56), random(+455))
  push();
  star(x, y, 20, 35, 9);
  pop();
}