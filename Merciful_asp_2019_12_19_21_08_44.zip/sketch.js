/*
    modulo operato
*/
let angle = 0;

let sliderA, sliderB;

function setup() {
  createCanvas(400, 400);
  
  
  sliderA = createSlider(30, 200, 5, 10);
  sliderB = createSlider(30, 200, 5, 10);
  sliderC = createSlider(30, 200, 5, 10);
  
}

function draw() {
  background(220, 23, 245);
  let a = sliderA.value();
  let b = sliderB.value();
  
  let r = a % b;

  
    for(let i = 0; i < width; i++){
    if(i <= a){stroke("blue");} else{stroke("brown");}
    let h = height - i%a;
      
    rotate(angle)
    fill(255)
    ellipse(i, height, i, h);
    ellipse(i, height, h, i);

    angle= angle + 3
    
  }
    for(let i = 0; i < width; i++)
    {if(i <= b){stroke("black");} else{stroke("black");}
    let h = height - i%b;
      
    rotate(angle)    
    ellipse(i, h, height, i)
    ellipse(i, height, h, i)
    angle= angle + 2
    
  }}